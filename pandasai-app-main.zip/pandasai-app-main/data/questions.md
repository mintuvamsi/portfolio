# Example Questions

To test out the APP, Below are Sample Questions for Two Data Files

## test_data.csv
It is tiny samples of Countries with  Happiness Index and gdp

1. Which are the 5 happiest countries?


## Loan Payments data.csv

This is sample of datasets with Loan Repayments. 

1. How many loans are from men that have been paid off?

> User Specific datasets can be tested, would love to have feedbacks and bugs.
